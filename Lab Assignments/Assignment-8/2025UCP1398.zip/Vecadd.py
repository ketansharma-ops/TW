
a = list(map(int, input("Enter the first vector: ").split()))
b = list(map(int, input("Enter the second vector: ").split()))

if len(a) != len(b):
    print("Error: Vectors must have the same length.")
else:
    dot_product = sum(x * y for x, y in zip(a, b))
    print("Dot product:", dot_product)
